local execString2 = 'trapsheet.bat'
os.execute(execString2)
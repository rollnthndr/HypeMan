-- INSTRUCTIONS
-- In the DCS mission do a single trigger, time more (1) that does a DO SCRIPT event
-- Paste this code into the DO SCRIPT:
-- assert(loadfile("C:/HypeMan/mission_script_loader.lua"))()

-- Script File Versions
-- Moose version 08 25 2019  (August 25, 2019)
-- Mist version 4.3.74
-- HypeMan version II.0
-- AirbossSkipper version whatever.blank

assert(loadfile("C:/HypeMan/mist.lua"))()
assert(loadfile("C:/HypeMan/Moose.lua"))()
assert(loadfile("C:/HypeMan/HypeMan.lua"))()
--assert(loadfile("C:/HypeMan/AirbossSkipper.lua"))()